//
//  NextViewController.swift
//  firstCodeDataProject
//
//  Created by Sukhveen Sandhu on 2017-07-12.
//  Copyright © 2017 Sukhveen Sandhu. All rights reserved.
//

import UIKit
import CoreData

class NextViewController: UIViewController 
{
    
       
    var stringPassed = ""
    var stringPassed1 = ""
    var stringPassed2 = ""
    var stringPassed3 = ""

    override func viewDidLoad() {
        super.viewDidLoad()

         // Do any additional setup after loading the view.
        save(eid: Int(stringPassed)!,ename: stringPassed2 , edob: stringPassed3, esalary: Double(stringPassed)!)
       
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func save(eid: Int, ename: String,edob: String,esalary: Double) {
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        // 1
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        // 2
        let entity =
            NSEntityDescription.entity(forEntityName: "Employee",
                                       in: managedContext)!
        
        let employee = NSManagedObject(entity: entity,
                                       insertInto: managedContext)
        
        // 3
        employee.setValue(eid, forKeyPath: "eid")
        employee.setValue(ename, forKeyPath: "enm")
        employee.setValue(edob, forKeyPath: "dob")
        employee.setValue(esalary, forKeyPath: "salary")
        
        
        // 4
        do {
            try managedContext.save()
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    
        
        //2
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "Employee")
        
        //3
        var allEmployees: [NSManagedObject] = []
        do {
            allEmployees = try managedContext.fetch(fetchRequest)
            
            for m in allEmployees
            {
                print((m as! Employee).enm!)
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }

   
    
     func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LabelCell", for: indexPath)
        
        cell.textLabel?.text = "Section \(indexPath.section) Row \(indexPath.row)"
        
        return cell
    }
    
   func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Section \(section)"
    }
    
}
