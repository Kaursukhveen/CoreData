//
//  ViewController.swift
//  firstCodeDataProject
//
//  Created by Sukhveen Sandhu on 2017-07-10.
//  Copyright © 2017 Sukhveen Sandhu. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBAction func btnSubmit(_ sender: Any) {
        let myVC = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
         myVC.stringPassed = txtEid.text!
         myVC.stringPassed1 = txtEname.text!
         myVC.stringPassed2 = txtdob.text!
         myVC.stringPassed3 = txtSalary.text!
        
        
        navigationController?.pushViewController(myVC, animated: true)
        
        
        
        
    }
   
    @IBOutlet weak var txtEid: UITextField!
    @IBOutlet weak var txtEname: UITextField!
    @IBOutlet weak var txtdob: UITextField!
    @IBOutlet weak var txtSalary: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
     
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }

    
    }
